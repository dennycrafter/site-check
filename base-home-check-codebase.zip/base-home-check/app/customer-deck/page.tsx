'use client';

import { useEffect, useState } from 'react';

type Kind = 'welcome' | 'safety' | 'find' | 'detected' | 'camera' | 'approved' | 'choice' | 'complete' | 'analyze' | 'eligible' | 'review' | 'ineligible' | 'retake';
type JourneyScreen = { label:string; section:string; eyebrow:string; title:string; body:string; action:string; kind:Kind; note:string; icon?:string; tip?:string; photo?:number; branch?:boolean; next?:number; secondary?:string };

const screens: JourneyScreen[] = [
  { label:'Welcome', section:'Start', eyebrow:'Home eligibility check', title:'Let’s check your electrical setup.', body:'We’ll guide you through a few exterior photos to see if your home may qualify for a Base battery.', action:'Start home check', kind:'welcome', icon:'⌂', note:'Sets scope and expected effort: exterior electrical photos only.' },
  { label:'Safety first', section:'Start', eyebrow:'Before you begin', title:'Stay outside and stay safe.', body:'Never remove a screwed-on panel cover or touch electrical wiring. We only need photos of equipment you can access safely.', action:'I understand', kind:'safety', icon:'!', note:'Safety acknowledgement before any capture instructions.' },
  { label:'Find meter', section:'Identify setup', eyebrow:'Find your equipment', title:'Start with your electric meter.', body:'Look for a gray box with a round glass meter on an exterior wall of your home.', action:'I found it', kind:'find', icon:'◎', tip:'Usually on the side or back of your home.', note:'Helps the customer identify the correct exterior equipment.' },
  { label:'Setup detected', section:'Identify setup', eyebrow:'Setup identified', title:'Meter with exterior breaker panel.', body:'We found your meter and main panel together outside. Your photo list has been adjusted for this setup.', action:'Begin photos', kind:'detected', icon:'✓', note:'The first image adapts the required shot list. This example needs seven photos.' },
  { label:'Meter close-up', section:'Guided photos', eyebrow:'Photo 1 of 7', title:'Meter and full metal box', body:'Fit the entire metal box inside the outline—from its top edge to its bottom edge. Move close enough for the complete meter number to be readable.', action:'Take photo', kind:'camera', icon:'◎', tip:'Stand straight in front of it and hold your phone upright.', photo:1, note:'Supports meter-number OCR plus meter-can type, size, and mount classification.' },
  { label:'Quality passed', section:'Guided photos', eyebrow:'Photo checked', title:'Meter photo looks good.', body:'The image is sharp, bright, and shows the correct equipment. We can use it for the eligibility check.', action:'Next photo', kind:'approved', icon:'✓', note:'Immediate validation prevents a later customer retake.' },
  { label:'Meter wall', section:'Guided photos', eyebrow:'Photo 2 of 7', title:'Step back for the full wall.', body:'Include the meter, the ground, the full wall above it, and the closest door, window, driveway, gas equipment, and corner.', action:'Take photo', kind:'camera', icon:'⌗', tip:'Turn your phone sideways. Wide is better.', photo:2, note:'Shows disconnect space, overhead access, ground conditions, clearances, and possible battery locations.' },
  { label:'Right side', section:'Guided photos', eyebrow:'Photo 3 of 7', title:'Wall and ground to the right', body:'Keep the meter in view and show the wall and ground as far right as possible.', action:'Take photo', kind:'camera', icon:'→', tip:'Include doors, windows, fences, AC units, pools, gas equipment, and driving surfaces.', photo:3, note:'Lets the qualifier search the whole reachable wall for one valid placement instead of judging only beside the meter.' },
  { label:'Left side', section:'Guided photos', eyebrow:'Photo 4 of 7', title:'Wall and ground to the left', body:'Keep the meter in view and show the wall and ground as far left as possible.', action:'Take photo', kind:'camera', icon:'←', tip:'Include the closest corner and anything fixed to the wall or ground.', photo:4, note:'Checks the alternate placement direction and confirms the route endpoint.' },
  { label:'Around corner', section:'Guided photos', eyebrow:'Photo 5 of 7', title:'Wall around the nearest corner', body:'Photograph the next wall from corner to corner, including the full ground area and open space above it.', action:'Take photo', kind:'camera', icon:'⌞', tip:'If a gate blocks the view, open it safely or photograph behind it.', photo:5, note:'Reveals adjacent-wall placements and the complete reachable harness path.' },
  { label:'Behind fence', section:'Conditional', eyebrow:'One more exterior view', title:'Is there a fence near the meter?', body:'If yes, show the full area behind it. This helps us understand access and usable space around the corner.', action:'Yes, take photo', secondary:'No fence nearby', kind:'choice', icon:'╫', note:'Conditional step appears only when a nearby fence is detected or reported.' },
  { label:'Find panel', section:'Main panel', eyebrow:'Main breaker panel', title:'Where is your main breaker panel?', body:'Choose the location that best matches your home. We’ll adjust the remaining instructions.', action:'Outside near meter', secondary:'Inside garage', kind:'choice', icon:'▤', note:'Typical branches are exterior, garage, or another accessible location.' },
  { label:'Panel context', section:'Main panel', eyebrow:'Photo 6 of 7', title:'Open main breaker panel', body:'Open only the normal hinged door. Capture the full panel straight on so the brand label and main breakers are visible.', action:'Take photo', kind:'camera', icon:'▤', tip:'Never remove screws or the inner metal cover.', photo:6, note:'Supports panel type, multiple-main, recall, condition, breaker orientation, and access checks.' },
  { label:'Open panel lid', section:'Main panel', eyebrow:'Open the hinged door', title:'Show the breakers inside.', body:'Open only the normal hinged panel door. Do not remove any screws or the inner metal cover.', action:'The door is open', kind:'safety', icon:'▥', tip:'Stop if the door is locked, damaged, or unsafe.', note:'Plain safety language ensures the main switch can be read without exposing wiring.' },
  { label:'Main disconnect', section:'Main panel', eyebrow:'Photo 7 of 7', title:'Main breaker or disconnect', body:'Take a clear close-up of the main breaker or separate disconnect enclosure, including its label and ON/OFF direction.', action:'Take photo', kind:'camera', icon:'200', tip:'Keep the surrounding box in frame so we can identify which equipment it belongs to.', photo:7, note:'Provides evidence for panel relationships, equipment condition, and independent-service classification.' },
  { label:'Photos complete', section:'Determine eligibility', eyebrow:'7 of 7 photos ready', title:'That’s everything we need.', body:'Your photos passed the quality check. We’re checking the wiring, equipment location, and available battery space.', action:'Check my eligibility', kind:'complete', icon:'✓', note:'Confirms the minimum photo set before analysis begins.' },
  { label:'Checking home', section:'Determine eligibility', eyebrow:'Checking your setup', title:'Reviewing your exterior system…', body:'We’re running twelve focused checks across the meter, panel, access, battery space, clearances, and wiring route.', action:'View result', kind:'analyze', icon:'◌', note:'Narrow checks make uncertainty explicit; any unclear evidence routes to manual review.' },
  { label:'Eligible', section:'Outcomes', eyebrow:'Eligibility result', title:'Your home looks like a fit.', body:'Your 200A service, exterior equipment layout, and available wall space appear compatible with up to two Base batteries.', action:'Finish home check', kind:'eligible', icon:'✓', note:'High-confidence pass. Battery count remains subject to final Base confirmation.' },
  { label:'Needs review', section:'Outcomes', eyebrow:'Eligibility result', title:'We need a closer look.', body:'Your home may qualify, but one check is close to a safety threshold. A Base specialist will review the photos instead of guessing.', action:'Finish home check', kind:'review', icon:'?', branch:true, note:'Manual review is the default for ambiguous evidence; it is distinct from needing more photos.' },
  { label:'Not eligible', section:'Outcomes', eyebrow:'Eligibility result', title:'This setup isn’t currently eligible.', body:'The main electrical service appears below the capacity required for this installation. Base will confirm before closing the review.', action:'Finish home check', kind:'ineligible', icon:'×', branch:true, note:'Clear failure includes a plain reason without exposing internal rule complexity.' },
  { label:'Retake request', section:'Exceptions', eyebrow:'Let’s try that photo again', title:'The panel lid is closed.', body:'Open the normal hinged door so the large main switch is visible, then take the same photo again.', action:'Retake photo', kind:'retake', icon:'!', branch:true, next:13, note:'Specific correction replaces a generic photo rejection.' },
];

export default function CustomerDeck() {
  const [current, setCurrent] = useState(0);
  const screen = screens[current];
  const advance = () => setCurrent(screen.next ?? Math.min(current + 1, 17));
  useEffect(() => {
    const onKey = (event:KeyboardEvent) => {
      if (event.key === 'ArrowRight') advance();
      if (event.key === 'ArrowLeft') setCurrent((value) => Math.max(0, value - 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  let lastSection = '';
  return (
    <main className="deck-shell">
      <header className="deck-header"><div className="brand"><span className="base-wordmark">BASE</span><span className="deck-product-name">Home eligibility</span></div><div><span>Customer eligibility journey</span><b>{current + 1} / {screens.length}</b></div></header>
      <div className="deck-body">
        <aside className="deck-nav">{screens.map((item, index) => { const showSection = item.section !== lastSection; lastSection = item.section; return <div className="deck-nav-item" key={`${item.label}-${index}`}>{showSection && <span className="deck-label">{item.section}</span>}<button className={current === index ? 'active' : ''} onClick={() => setCurrent(index)}><i>{index + 1}</i><span>{item.label}{item.branch && <small>Branch</small>}</span></button></div>; })}</aside>
        <section className="deck-stage">
          <div className={`phone-frame phone-${screen.kind} ${screen.kind === 'camera' && [1,7].includes(screen.photo ?? 0) ? 'capture-portrait' : screen.kind === 'camera' ? 'capture-landscape' : ''}`}>
            <div className="phone-top"><span className="base-wordmark phone-wordmark">BASE</span><small>{screen.photo ? `Photo ${screen.photo} of 7` : 'Home eligibility'}</small><button aria-label="Help">?</button></div>
            <div className="phone-progress"><i style={{ width: `${Math.min(((current + 1) / 18) * 100, 100)}%` }} /></div>
            {screen.kind === 'camera' ? <CameraScreen screen={screen} advance={advance} /> : <StandardScreen screen={screen} advance={advance} current={current} setCurrent={setCurrent} />}
          </div>
          <div className="deck-notes"><span>{screen.branch ? 'Alternative branch' : `Screen ${String(current + 1).padStart(2, '0')}`}</span><h2>{screen.label}</h2><p>{screen.note}</p><div className="deck-controls"><button disabled={current === 0} onClick={() => setCurrent(Math.max(0,current - 1))}>← Previous</button><button disabled={current === screens.length - 1} onClick={() => setCurrent(Math.min(screens.length - 1,current + 1))}>Next →</button></div><small>Tip: use ← and → keys to present.</small></div>
        </section>
      </div>
    </main>
  );
}

function CameraScreen({ screen, advance }:{ screen:JourneyScreen; advance:()=>void }) {
  const shots = ['Meter + full can','Full meter wall','Right-side space','Left-side space','Adjacent wall','Open main panel','Main disconnect'];
  const active = Math.max(0, (screen.photo ?? 1) - 1);
  const isWide = ![1,7].includes(screen.photo ?? 0);
  const [aligned, setAligned] = useState(false);
  useEffect(() => {
    setAligned(false);
    const timer = window.setTimeout(() => setAligned(true), 900);
    return () => window.clearTimeout(timer);
  }, [screen.photo]);
  const hearInstructions = () => {
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(`${screen.title}. ${screen.body}. ${screen.tip ?? ''}`));
  };
  return <div className="deck-camera landscape-capture">
    <div className="capture-statusbar"><b>BASE</b><span>Step {active + 1} of 7</span><i className={aligned ? 'ready' : ''}>{aligned ? '✓ Ready to take photo' : 'Finding equipment…'}</i></div>
    <aside className="orientation-rail"><div className={`phone-tilt ${isWide ? 'wide' : ''}`}><i /><span>↻</span></div><b>{isWide ? 'Turn your phone sideways' : 'Keep your phone upright'}</b><small>Use both hands. Move slowly.</small></aside>
    <section className="capture-workspace">
      <div className={`deck-viewfinder guide-photo photo-${screen.photo}`}>
        <span className="deck-light">● Good light</span><span className="deck-example-label">Live guide</span>
        <div className={`equipment-outline target-${screen.photo} ${aligned ? 'aligned' : ''}`}><i /><i /><i /><i /><span>{aligned ? '✓' : screen.icon}</span></div>
        {!aligned && <div className="scan-line" />}
        <b className={`alignment-prompt ${aligned ? 'aligned' : ''}`} aria-live="polite">{aligned ? 'Equipment aligned · hold steady' : `Place ${screen.title.toLowerCase()} inside the outline`}</b>
      </div>
      <div className="capture-instruction"><div><b>{screen.title}</b><span>{screen.body}</span></div>{screen.tip && <small>Tip · {screen.tip}</small>}</div>
    </section>
    <aside className="shot-rail simple-capture-rail"><span className="large-step">Photo {active + 1} of 7</span><h2>{shots[active]}</h2><ol><li>Point your camera at the equipment.</li><li>Fit it inside the red outline.</li><li>Hold still until the outline turns green.</li></ol><button className="hear-guide" onClick={hearInstructions}>🔊 Hear these instructions</button><div className="capture-meter"><b>{active} complete</b><span><i style={{width:`${(active/7)*100}%`}} /></span></div><button className="capture-trigger" aria-label={screen.action} onClick={advance} disabled={!aligned}><i /><span>{aligned ? 'Take photo' : 'Hold still…'}</span></button><button className="help-capture">Need help?</button></aside>
  </div>;
}

function StandardScreen({ screen, advance, current, setCurrent }:{ screen:JourneyScreen; advance:()=>void; current:number; setCurrent:(value:number)=>void }) {
  const examplePhoto = screen.kind === 'find' || screen.kind === 'approved' ? 1 : screen.kind === 'detected' ? 6 : screen.label === 'Open panel lid' || screen.kind === 'retake' ? 7 : 0;
  const showAnalysisVisual = screen.kind === 'detected' || screen.kind === 'analyze';
  return <div className="phone-content"><div className={`screen-art art-${screen.kind} ${examplePhoto && !showAnalysisVisual ? `photo-example photo-${examplePhoto}` : ''} ${showAnalysisVisual ? 'analysis-visual' : ''}`}><span>{screen.icon}</span>{examplePhoto > 0 && !showAnalysisVisual && <b className="screen-example-chip">Capture example</b>}{showAnalysisVisual && <b className="screen-example-chip">Qualification overlay</b>}{screen.kind === 'analyze' && <div className="analysis-list"><i className="done">✓ Equipment views matched</i><i className="done">✓ 11 focused checks clean</i><i>◌ Battery space → manual review</i></div>}{['eligible','review','ineligible'].includes(screen.kind) && <div className="result-facts"><i><b>{screen.kind === 'eligible' ? '12/12' : screen.kind === 'review' ? '11/12' : 'Reject'}</b><small>Qualifier checks</small></i><i><b>{screen.kind === 'eligible' ? 'Pass' : screen.kind === 'review' ? 'Review' : 'No'}</b><small>Routing result</small></i></div>}</div><div className="phone-eyebrow">{screen.eyebrow}</div><h1>{screen.title}</h1><p>{screen.body}</p>{screen.tip && <div className="phone-tip">{screen.tip}</div>}{screen.kind === 'choice' && <div className="choice-preview"><button className="selected">{screen.action}<i>✓</i></button><button>{screen.secondary}<i /></button></div>}<button className="deck-primary" onClick={advance}>{screen.kind === 'choice' ? 'Continue' : screen.action}<span>→</span></button>{screen.secondary && screen.kind !== 'choice' && <button className="deck-secondary" onClick={advance}>{screen.secondary}</button>}{current === 17 && <button className="deck-secondary" onClick={() => setCurrent(18)}>Preview other outcomes</button>}</div>;
}
