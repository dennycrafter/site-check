'use client';

import { ChangeEvent, useMemo, useRef, useState } from 'react';

type Screen = 'ops' | 'case' | 'intro' | 'details' | 'capture' | 'electrical' | 'review' | 'result';
type Answer = 'yes' | 'no' | '';

const photoSteps = [
  { id: 'meter', title: 'Electric meter and full metal box', short: 'Meter close-up', instruction: 'Photograph the meter straight on. Include the full metal box from its top edge to its bottom edge.', tip: 'Move close enough for the complete meter number to be sharp and readable.', icon: '◎' },
  { id: 'surroundings', title: 'Full wall around the meter', short: 'Meter wall', instruction: 'Step back and show the meter, wall, ground, and open space above it.', tip: 'Include doors, windows, driveways, gas equipment, and the nearest corner.', icon: '⌗' },
  { id: 'right', title: 'Wall and ground to the right', short: 'Right side', instruction: 'Keep the meter in the photo and show the wall and ground as far right as you can.', tip: 'Include fences, windows, doors, AC units, pools, and driving surfaces.', icon: '→' },
  { id: 'left', title: 'Wall and ground to the left', short: 'Left side', instruction: 'Keep the meter in the photo and show the wall and ground as far left as you can.', tip: 'Include the nearest corner and anything fixed to the wall or ground.', icon: '←' },
  { id: 'adjacent', title: 'Wall around the nearest corner', short: 'Around the corner', instruction: 'Capture the next wall from corner to corner, including the full ground area.', tip: 'If a gate or fence blocks the view, open it safely or photograph behind it.', icon: '⌞' },
  { id: 'panel', title: 'Open main breaker panel', short: 'Breaker panel', instruction: 'Open only the normal hinged door and photograph the full panel straight on.', tip: 'Make the brand label and every main breaker visible. Never remove screws.', icon: '▤' },
  { id: 'disconnect', title: 'Main breaker or disconnect', short: 'Main disconnect', instruction: 'Take a focused close-up of the main breaker or separate disconnect enclosure.', tip: 'Include its label, ON/OFF direction, and surrounding enclosure.', icon: '⌁' },
];

export default function Home() {
  const [screen, setScreen] = useState<Screen>('ops');
  const [photoIndex, setPhotoIndex] = useState(0);
  const [photos, setPhotos] = useState<Record<string, { name: string; url: string; status: 'checking' | 'pass' | 'retake'; message?: string }>>({});
  const [zip, setZip] = useState('');
  const [utility, setUtility] = useState('');
  const [solar, setSolar] = useState<Answer>('');
  const [battery, setBattery] = useState<Answer>('');
  const [breaker, setBreaker] = useState('');
  const [obstructions, setObstructions] = useState<Answer>('');
  const [helpOpen, setHelpOpen] = useState(false);
  const [batchState, setBatchState] = useState<'idle' | 'running' | 'done'>('idle');
  const [caseDecision, setCaseDecision] = useState<'review' | 'approved' | 'retake' | 'failed'>('review');
  const fileRef = useRef<HTMLInputElement>(null);

  const captured = Object.values(photos).filter((photo) => photo.status === 'pass').length;
  const currentPhoto = photoSteps[photoIndex];
  const detailsReady = /^\d{5}$/.test(zip) && utility && solar && battery;
  const electricalReady = breaker && obstructions;
  const completion = useMemo(() => {
    if (screen === 'ops' || screen === 'intro') return 0;
    if (screen === 'details') return 10;
    if (screen === 'capture') return 20 + Math.round((captured / photoSteps.length) * 55);
    if (screen === 'electrical') return 80;
    if (screen === 'review') return 92;
    return 100;
  }, [screen, captured]);

  const goBack = () => {
    if (screen === 'details') setScreen('intro');
    else if (screen === 'capture') photoIndex > 0 ? setPhotoIndex(photoIndex - 1) : setScreen('details');
    else if (screen === 'electrical') { setScreen('capture'); setPhotoIndex(photoSteps.length - 1); }
    else if (screen === 'review') setScreen('electrical');
  };

  const handleFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const old = photos[currentPhoto.id];
    if (old?.url.startsWith('blob:')) URL.revokeObjectURL(old.url);
    const id = currentPhoto.id;
    const nextPhotoUrl = URL.createObjectURL(file);
    setPhotos({ ...photos, [id]: { name: file.name, url: nextPhotoUrl, status: 'checking' } });
    window.setTimeout(() => {
      const needsRetake = /dark|blurry|closed|wrong/i.test(file.name);
      setPhotos((current) => ({ ...current, [id]: { ...current[id], status: needsRetake ? 'retake' : 'pass', message: needsRetake ? (/closed/i.test(file.name) ? 'Lift the panel lid and try again.' : /dark/i.test(file.name) ? 'This photo is too dark. Move into daylight.' : 'Hold steady and keep the full subject in frame.') : 'Sharp, bright, and the right subject.' } }));
    }, 900);
    event.target.value = '';
  };

  const nextPhoto = () => {
    if (photoIndex < photoSteps.length - 1) setPhotoIndex(photoIndex + 1);
    else setScreen('electrical');
  };

  const addDemoPhotos = () => {
    const seeded = Object.fromEntries(photoSteps.map((photo) => [photo.id, { name: `${photo.id}.jpg`, url: '', status: 'pass' as const, message: 'Sharp, bright, and the right subject.' }]));
    setPhotos(seeded);
    setPhotoIndex(0);
    setScreen('capture');
  };

  const potentiallyEligible = battery !== 'yes' && Number(breaker) >= 100 && !(solar === 'yes' && Number(breaker) < 200);
  const runBatch = () => {
    setBatchState('running');
    window.setTimeout(() => setBatchState('done'), 2200);
  };

  return (
    <main className={`app-shell screen-${screen}`}>
      <header className="app-header">
        <button className="brand" aria-label="Base photo qualification home" onClick={() => setScreen('ops')}>
          <span className="base-wordmark">BASE</span><span>Photo <em>Qualification</em></span>
        </button>
        {screen !== 'ops' && screen !== 'intro' && screen !== 'result' && (
          <div className="progress-wrap" aria-label={`${completion}% complete`}>
            <span>{completion}% complete</span><div className="progress"><i style={{ width: `${completion}%` }} /></div>
          </div>
        )}
        <div className="header-actions"><button className="customer-view" type="button" onClick={() => { if (screen === 'ops' || screen === 'case') window.location.href = '/customer-deck'; else setScreen('ops'); }}>{screen === 'ops' || screen === 'case' ? 'View customer deck' : 'Team workspace'}</button><button className="help-button" type="button" onClick={() => setHelpOpen(true)}>Help</button></div>
      </header>

      {screen === 'ops' && (
        <section className="ops-page">
          <div className="ops-hero">
            <div><div className="step-kicker">Qualification operations</div><h2>Good morning, Maya.</h2><p>Homes are being checked as photos arrive. Your team only needs to review the uncertain ones.</p></div>
            <div className="ops-actions"><button className="secondary" onClick={() => setScreen('intro')}>Customer demo</button><button className="primary" onClick={runBatch} disabled={batchState === 'running'}>{batchState === 'running' ? 'Checking 12 homes…' : batchState === 'done' ? '12 checks complete' : 'Run parallel check'} <span>{batchState === 'running' ? '•••' : '→'}</span></button></div>
          </div>
          {batchState !== 'idle' && <div className={`batch-banner ${batchState}`}><span className="batch-pulse" /><div><b>{batchState === 'running' ? 'Running 12 independent qualification checks' : 'Batch complete in 4.2 seconds'}</b><small>{batchState === 'running' ? 'Meter ID · equipment type · panel safety · placement · access' : '8 auto-passed · 1 rejected · 2 manual review · 1 needs photos'}</small></div><code>{batchState === 'running' ? 'PROCESSING' : 'CONSERVATIVE ROUTING'}</code></div>}
          <div className="ops-metrics">
            <article><span>In review</span><strong>8</strong><small>3 need attention</small></article>
            <article><span>Auto-decided today</span><strong>84%</strong><small className="up">↑ 6% this week</small></article>
            <article><span>Median check</span><strong>3.8s</strong><small>photo to verdict</small></article>
            <article><span>Retakes avoided</span><strong>31</strong><small>this week</small></article>
          </div>
          <div className="ops-panel">
            <div className="panel-head"><div><h3>Qualification queue</h3><span>Live · updated just now</span></div><div className="queue-tabs"><button className="active">All <b>24</b></button><button>Review <b>3</b></button><button>Retake <b>5</b></button></div></div>
            <div className="queue-table">
              <div className="queue-row table-labels"><span>Home</span><span>Setup</span><span>Checks</span><span>Decision</span><span>Processed</span><span /></div>
              <div className="queue-row"><span><i className="home-chip">ML</i><b>Martinez residence</b><small>Austin · #BQ-2918</small></span><span><b>Meter + exterior panel</b><small>7 photos</small></span><span><span className="check-stack"><i /><i /><i /><i /></span><small>12/12 clean</small></span><span><mark className="status pass">Auto-pass</mark></span><span><b>3.2 seconds</b><small>10:42 AM</small></span><button className="row-arrow">→</button></div>
              <div className="queue-row attention"><span><i className="home-chip amber">JW</i><b>Wilson residence</b><small>Dallas · #BQ-2917</small></span><span><b>Garage panel</b><small>8 photos</small></span><span><span className="check-stack"><i /><i /><i className="warn" /><i /></span><small>11 clean · 1 uncertain</small></span><span><mark className="status review">Manual review</mark></span><span><b>4.1 seconds</b><small>10:39 AM</small></span><button className="row-arrow" onClick={() => { setCaseDecision('review'); setScreen('case'); }} aria-label="Open Wilson residence">→</button></div>
              <div className="queue-row"><span><i className="home-chip rose">RC</i><b>Chen residence</b><small>Houston · #BQ-2916</small></span><span><b>All-in-one panel</b><small>7 photos</small></span><span><span className="check-stack"><i /><i className="bad" /><i /><i /></span><small>Near-certain no</small></span><span><mark className="status fail">Reject · no space</mark></span><span><b>3.6 seconds</b><small>10:31 AM</small></span><button className="row-arrow">→</button></div>
              <div className="queue-row"><span><i className="home-chip blue">AK</i><b>King residence</b><small>Round Rock · #BQ-2915</small></span><span><b>Meter + exterior panel</b><small>5 of 7 photos</small></span><span><span className="check-stack"><i /><i /><i /><i className="warn" /></span><small>Photo quality</small></span><span><mark className="status retake">Retake requested</mark></span><span><b>2.9 seconds</b><small>10:26 AM</small></span><button className="row-arrow">→</button></div>
            </div>
          </div>
          <div className="insight-strip"><div className="insight-label"><span>↗</span><div><b>Operational insight</b><small>Based on the last 148 submissions</small></div></div><p><strong>42% of retakes</strong> are caused by closed panel lids—your most common avoidable delay.</p><button onClick={() => setScreen('intro')}>See customer prompt →</button></div>
        </section>
      )}

      {screen === 'case' && (
        <section className="case-page">
          <button className="back" onClick={() => setScreen('ops')}>← Qualification queue</button>
          <div className="case-heading"><div><div className="step-kicker">#BQ-2917 · Dallas, TX</div><h2>Wilson residence</h2><p>Submitted today at 10:39 AM · processed in <b>4.1 seconds</b></p></div><div className={`case-state ${caseDecision}`}><span>{caseDecision === 'review' ? 'Needs review' : caseDecision === 'approved' ? 'Approved · 1 battery' : caseDecision === 'retake' ? 'Retake requested' : 'Does not qualify'}</span><small>{caseDecision === 'review' ? '1 rule is uncertain' : 'Decision updated just now'}</small></div></div>
          <div className="case-grid">
            <aside className="photo-rail">
              <div className="rail-head"><h3>Submission</h3><span>8 photos</span></div>
              {['Meter close-up','Meter wall','Right side','Left side','Adjacent wall','Panel open','Main disconnect','Garage context'].map((label, index) => <button key={label} className={index === 2 ? 'flagged' : index === 0 ? 'selected' : ''}><div className={`mini-photo p${index}`}><span>{index === 5 ? '▤' : index === 6 ? '200' : '⌂'}</span></div><span><b>{label}</b><small>{index === 2 ? 'Clearance uncertain' : index === 5 ? 'Lid open · clear' : 'Quality passed'}</small></span><i>{index === 2 ? '!' : '✓'}</i></button>)}
            </aside>
            <div className="case-main">
              <section className="decision-card">
                <div className="decision-top"><div><span className="status review">Manual review</span><h3>One placement check is uncertain</h3><p>Eleven checks are clean. The visible battery spot is near the drive-path threshold, so the qualifier deferred instead of guessing. The deciding area is already visible; no new photo is required.</p></div><div className="confidence"><strong>11/12</strong><span>clean checks</span></div></div>
                <div className="rule-grid">
                  <article><span className="rule-icon pass">✓</span><div><b>Meter identity</b><small>Single meter · complete number readable</small></div><em>Clean</em></article>
                  <article><span className="rule-icon pass">✓</span><div><b>Meter type + mount</b><small>Standard can · wall mounted</small></div><em>Clean</em></article>
                  <article><span className="rule-icon pass">✓</span><div><b>Main panel safety</b><small>Single modern panel · no recalled brand</small></div><em>Pass</em></article>
                  <article><span className="rule-icon pass">✓</span><div><b>Equipment access</b><small>Meter and panel working space visible</small></div><em>Pass</em></article>
                  <article className="uncertain"><span className="rule-icon review">!</span><div><b>Battery space</b><small>Drive path appears about 5–6 ft away</small></div><em>Manual review</em></article>
                  <article><span className="rule-icon pass">✓</span><div><b>Harness route</b><small>Visible wall run · no door or garage crossing</small></div><em>Pass</em></article>
                </div>
              </section>
              <section className="pipeline-card">
                <div className="section-title"><div><h3>Qualification pipeline</h3><span>Twelve narrow checks run independently. Any unclear check routes the home here.</span></div><code>4.1s TOTAL</code></div>
                <div className="pipeline">
                  <article><span>01</span><div><b>Evidence organized</b><small>Views matched across meter, wall, panel, and disconnect</small></div><em>0.8s</em></article>
                  <article><span>02</span><div><b>Equipment classified</b><small>Meter number, can, mount, panel type, and recall</small></div><em>1.2s</em></article>
                  <article><span>03</span><div><b>Placement checked</b><small>Best reachable spot, access, clearances, and harness route</small></div><em>1.7s</em></article>
                  <article className="routed"><span>04</span><div><b>Conservative router</b><small>11 clean · 1 uncertain → manual review</small></div><em>0.4s</em></article>
                </div>
                <div className="console-log"><div><span>10:39:14.082</span> meter_type=<b>standardMeter</b> clean=true</div><div><span>10:39:15.794</span> panel_recall=<b>pass</b></div><div><span>10:39:17.301</span> drive_path_ft=<b>5–6</b> decision=manual_review</div><div><span>10:39:17.304</span> needs_more_photos=<b>false</b></div></div>
              </section>
              <section className="case-actions"><div><b>Resolve this home</b><span>Your correction is recorded for rule tuning.</span></div><button className="secondary danger" onClick={() => setCaseDecision('failed')}>Fail home</button><button className="secondary" onClick={() => setCaseDecision('retake')}>Request one retake</button><button className="primary" onClick={() => setCaseDecision('approved')}>Approve 1 battery <span>✓</span></button></section>
            </div>
          </div>
        </section>
      )}

      {screen === 'intro' && (
        <div className="intro-layout">
          <section className="welcome">
            <div className="eyebrow"><span className="live-dot" /> Home eligibility check</div>
            <h1>Let’s find the right spot for your battery.</h1>
            <p className="lede">A few guided photos help our engineers understand your electrical setup and find a safe, code-compliant installation location.</p>
            <div className="time-card"><span className="time-icon">◷</span><div><strong>About 5 minutes</strong><span>Have access to your electric meter and breaker panel.</span></div></div>
            <div className="intro-actions"><button className="primary" type="button" onClick={() => setScreen('details')}>Start home check <span>→</span></button><button className="text-button" onClick={addDemoPhotos}>Preview demo</button></div>
            <p className="privacy">Your photos are securely shared with Base’s engineering team.</p>
          </section>
          <aside className="preview-card" aria-hidden="true">
            <div className="meter-art"><span className="meter-ring"><b>04281</b></span><i /></div><div className="scan-line" />
            <span className="preview-label">Guided capture</span><p>We’ll show you exactly what to photograph.</p>
          </aside>
        </div>
      )}

      {screen === 'details' && (
        <section className="form-page narrow">
          <button className="back" onClick={goBack}>← Back</button>
          <div className="step-kicker">Step 1 of 4 · Home details</div>
          <h2>First, tell us about your home.</h2>
          <p className="section-lede">This helps us apply the right local electrical and utility requirements.</p>
          <div className="field-grid">
            <label className="field"><span>ZIP code</span><input inputMode="numeric" maxLength={5} placeholder="78704" value={zip} onChange={(e) => setZip(e.target.value.replace(/\D/g, ''))} /><small>{zip && !/^\d{5}$/.test(zip) ? 'Enter a 5-digit ZIP code.' : 'Where the battery would be installed.'}</small></label>
            <label className="field"><span>Electric utility</span><select value={utility} onChange={(e) => setUtility(e.target.value)}><option value="">Select your utility</option><option>Oncor</option><option>CenterPoint</option><option>Austin Energy</option><option>CoServ</option><option>GVEC</option><option>Farmers Electric</option><option>Other / not sure</option></select><small>Shown on your electric bill.</small></label>
          </div>
          <Question title="Do you have rooftop solar?" value={solar} onChange={setSolar} note="Solar homes typically require a 200A panel." />
          <Question title="Do you already have a home battery?" value={battery} onChange={setBattery} note="Existing Powerwall, Enphase, or similar systems may not be compatible." />
          <button className="primary continue" disabled={!detailsReady} onClick={() => setScreen('capture')}>Continue to photos <span>→</span></button>
        </section>
      )}

      {screen === 'capture' && (
        <section className="capture-page">
          <div className="capture-copy">
            <button className="back" onClick={goBack}>← Back</button>
            <div className="step-kicker">Step 2 of 4 · Photo {photoIndex + 1} of {photoSteps.length}</div>
            <h2>{currentPhoto.title}</h2>
            <p className="section-lede">{currentPhoto.instruction}</p>
            <div className="tip"><b>Photo tip</b><span>{currentPhoto.tip}</span></div>
            <div className="photo-dots" aria-label="Photo progress">{photoSteps.map((photo, index) => <button key={photo.id} aria-label={`Go to ${photo.title}`} className={photos[photo.id]?.status === 'pass' ? 'done' : photos[photo.id]?.status === 'retake' ? 'needs-retake' : index === photoIndex ? 'active' : ''} onClick={() => setPhotoIndex(index)}>{photos[photo.id]?.status === 'pass' ? '✓' : photos[photo.id]?.status === 'retake' ? '!' : index + 1}</button>)}</div>
          </div>
          <div className={`camera-card ${photos[currentPhoto.id] ? 'has-photo' : ''}`}>
            {photos[currentPhoto.id]?.url ? <img src={photos[currentPhoto.id].url} alt={`Captured ${currentPhoto.title}`} /> : <div className="camera-scene"><div className="guide-box"><span className="guide-icon">{currentPhoto.icon}</span><b>Align {currentPhoto.short.toLowerCase()} here</b></div><div className="corner tl" /><div className="corner tr" /><div className="corner bl" /><div className="corner br" /></div>}
            {photos[currentPhoto.id] && <div className={`captured-badge ${photos[currentPhoto.id].status}`}>{photos[currentPhoto.id].status === 'checking' ? '◌ Checking photo…' : photos[currentPhoto.id].status === 'retake' ? `! ${photos[currentPhoto.id].message}` : `✓ ${photos[currentPhoto.id].message}`}</div>}
            <input ref={fileRef} className="file-input" type="file" accept="image/*" capture="environment" onChange={handleFile} />
            <div className="camera-actions"><button className="capture-button" onClick={() => fileRef.current?.click()}><span>●</span>{photos[currentPhoto.id] ? 'Retake photo' : 'Take photo'}</button>{photos[currentPhoto.id]?.status === 'pass' && <button className="primary next-photo" onClick={nextPhoto}>{photoIndex === photoSteps.length - 1 ? 'Electrical check' : 'Use photo'} <span>→</span></button>}</div>
          </div>
        </section>
      )}

      {screen === 'electrical' && (
        <section className="form-page narrow">
          <button className="back" onClick={goBack}>← Back</button>
          <div className="step-kicker">Step 3 of 4 · Electrical check</div>
          <h2>A couple of final checks.</h2>
          <p className="section-lede">Don’t worry if you’re unsure—an engineer will verify everything in your photos.</p>
          <fieldset className="question"><legend>What number is printed on your main breaker?</legend><div className="rating-grid">{['100','125','150','200','Not sure'].map((item) => <button type="button" key={item} className={breaker === item ? 'selected' : ''} onClick={() => setBreaker(item)}>{item}{item !== 'Not sure' && <small>amps</small>}</button>)}</div></fieldset>
          <Question title="Are there major obstructions within 3 feet of the meter wall?" value={obstructions} onChange={setObstructions} note="Examples: gas meter, AC unit, fence, window, or large shrubs." />
          <div className="safety-note"><span>i</span><p><b>Safety first</b> Never remove the panel’s screwed-on inner cover or touch wiring. We only need the main switch number.</p></div>
          <button className="primary continue" disabled={!electricalReady} onClick={() => setScreen('review')}>Review home check <span>→</span></button>
        </section>
      )}

      {screen === 'review' && (
        <section className="review-page">
          <button className="back" onClick={goBack}>← Back</button>
          <div className="review-head"><div><div className="step-kicker">Step 4 of 4 · Review</div><h2>Everything look right?</h2><p className="section-lede">Your photos will be reviewed by a Base engineer—not approved automatically.</p></div><div className="review-count"><strong>{captured}/{photoSteps.length}</strong><span>photos ready</span></div></div>
          <div className="review-grid">{photoSteps.map((photo, index) => <button className="review-card" key={photo.id} onClick={() => { setPhotoIndex(index); setScreen('capture'); }}><div className="thumb">{photos[photo.id]?.url ? <img src={photos[photo.id].url} alt="" /> : <span>{photo.icon}</span>}<i>{photos[photo.id]?.status === 'pass' ? '✓' : photos[photo.id]?.status === 'retake' ? '!' : '+'}</i></div><span>{photo.short}</span><small>{photos[photo.id]?.status === 'pass' ? 'Ready' : photos[photo.id]?.status === 'retake' ? 'Retake needed' : 'Add photo'}</small></button>)}</div>
          <div className="summary-strip"><div><span>Utility</span><b>{utility || 'Demo utility'}</b></div><div><span>Main breaker</span><b>{breaker || 'Not sure'}</b></div><div><span>Solar</span><b>{solar === 'yes' ? 'Yes' : solar === 'no' ? 'No' : 'Not provided'}</b></div><button onClick={() => setScreen('details')}>Edit</button></div>
          <label className="consent"><input type="checkbox" defaultChecked /><span>I confirm these photos show my home and may be reviewed to assess installation eligibility.</span></label>
          <button className="primary submit" disabled={captured < photoSteps.length} onClick={() => setScreen('result')}>Submit for review <span>→</span></button>
        </section>
      )}

      {screen === 'result' && (
        <section className="result-page">
          <div className={`result-orb ${potentiallyEligible ? '' : 'caution'}`}><span>{potentiallyEligible ? '✓' : '!'}</span></div>
          <div className="eyebrow centered"><span className="live-dot" /> Home check received</div>
          <h2>{potentiallyEligible ? 'Your home looks like a potential fit.' : 'Your setup needs a closer look.'}</h2>
          <p>{potentiallyEligible ? 'A Base engineer will review your photos and confirm the electrical and spacing requirements. Most reviews are completed within two business days.' : 'One or more answers may require a different configuration or may not meet current installation requirements. A Base engineer will verify your submission.'}</p>
          <div className="result-details"><div><span>Reference</span><b>BH-{zip || '78704'}-28F</b></div><div><span>Status</span><b>Engineering review</b></div><div><span>What’s next</span><b>We’ll contact you</b></div></div>
          <div className="result-actions"><button className="primary" onClick={() => window.print()}>Save confirmation <span>↗</span></button><button className="text-button" onClick={() => { setScreen('intro'); setPhotos({}); setPhotoIndex(0); }}>Start another check</button></div>
        </section>
      )}

      {helpOpen && <div className="modal-backdrop" role="presentation" onMouseDown={() => setHelpOpen(false)}><section className="help-modal" role="dialog" aria-modal="true" aria-labelledby="help-title" onMouseDown={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setHelpOpen(false)}>×</button><div className="help-icon">?</div><h3 id="help-title">We’re here to help.</h3><p>Having trouble finding your meter or main breaker? You can continue with what you know—our team will follow up if another photo is needed.</p><a href="tel:+18882022220">Call (888) 202-2220</a><button className="secondary" onClick={() => setHelpOpen(false)}>Back to home check</button></section></div>}
    </main>
  );
}

function Question({ title, value, onChange, note }: { title: string; value: Answer; onChange: (value: Answer) => void; note: string }) {
  return <fieldset className="question"><legend>{title}</legend><div className="option-row"><button type="button" className={value === 'yes' ? 'selected' : ''} onClick={() => onChange('yes')}><span>Yes</span><i>✓</i></button><button type="button" className={value === 'no' ? 'selected' : ''} onClick={() => onChange('no')}><span>No</span><i>✓</i></button></div><small>{note}</small></fieldset>;
}
